# About me

Here is where I explain all the _interesting_ things that made me want to make this site in the first place!

Do I ski? Do I make jewelry out of used toothpicks? 

I bet you'd like to know!


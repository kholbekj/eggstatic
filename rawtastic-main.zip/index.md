# Welcome to My Site!

This is my new site built with Eggstatic. This page can be changed by editing `index.md`

## Pages

- [About me](content/about.md)
